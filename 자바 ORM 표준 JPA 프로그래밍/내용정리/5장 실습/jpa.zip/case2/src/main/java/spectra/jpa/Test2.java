package spectra.jpa;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class Test2 /*implements ApplicationRunner*/ {

    private final MemberRepository memberRepository;

    public void run(ApplicationArguments args) throws Exception {

        Member member = new Member("shjeon2", "전소희");
        Team team = new Team("team1", "팀1");
        member.setTeam(team);
        memberRepository.save(member);
    }
}
