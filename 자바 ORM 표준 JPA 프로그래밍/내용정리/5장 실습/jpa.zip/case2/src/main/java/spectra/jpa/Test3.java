package spectra.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class Test3 /*implements ApplicationRunner*/ {

    private final MemberRepository memberRepository;

    public void run(ApplicationArguments args) throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("simple-jpa-application");
        EntityManager em = emf.createEntityManager();

        String jpql = "select m from Member m join m.team t where t.name='팀1'";
        List<Member> resultList = em.createQuery(jpql, Member.class).getResultList();

        for (Member member : resultList)
        {
            System.out.println(member.getUsername());
        }

    }
}
