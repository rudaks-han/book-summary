package spectra.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Case2Main {
    public static void main(String[] args) {
        SpringApplication.run(Case2Main.class, args);
    }
}
