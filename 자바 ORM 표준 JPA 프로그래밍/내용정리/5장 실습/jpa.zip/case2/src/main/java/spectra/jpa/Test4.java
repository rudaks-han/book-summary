package spectra.jpa;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class Test4 /*implements ApplicationRunner*/ {

    public void run(ApplicationArguments args) throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("simple-jpa-application");
        EntityManager em = emf.createEntityManager();

        EntityTransaction transaction = em.getTransaction();
        transaction.begin();

        Team team2 = new Team("team2","팀2");
        em.persist(team2);

        Member member = em.find(Member.class, "shjeon");
        member.setTeam(team2);

        transaction.commit();
    }
}
