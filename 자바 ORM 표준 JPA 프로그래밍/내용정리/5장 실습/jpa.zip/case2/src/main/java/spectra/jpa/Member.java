package spectra.jpa;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="MEMBER")
@Getter @Setter
@NoArgsConstructor
public class Member {
    @Id
    @Column(name="MEMBER_ID")
    private String id;

    private String username;

    // 연관관계 매핑
    @ManyToOne
    @JoinColumn(name="TEAM_ID")
    private Team team;  // Team 참조

    public Member(String id, String username, Team team)
    {
        this.id = id;
        this.username = username;
        this.team = team;
    }

    public Member(String id, String username)
    {
        this.id = id;
        this.username = username;
    }
}
