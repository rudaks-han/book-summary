package spectra.jpa;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
public class Team {
    private String id;
    private String name;

    public Team(String id, String name)
    {
        this.id = id;
        this.name = name;
    }

}
