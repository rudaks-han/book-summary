package spectra.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class Test1 /*implements ApplicationRunner */{

    public void run(ApplicationArguments args) throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("simple-jpa-application");
        EntityManager em = emf.createEntityManager();
        Team team = new Team("team2", "팀2");
        em.persist(team);

        Member member1 = new Member("shjeon01", "회원01");
        member1.setTeam(team);
        em.persist(member1);

        Member member2 = new Member("shjeon02", "회원02");
        member1.setTeam(team);
        em.persist(member2);
    }
}
