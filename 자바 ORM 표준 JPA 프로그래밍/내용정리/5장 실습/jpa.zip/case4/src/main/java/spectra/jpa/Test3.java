package spectra.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class Test3 implements ApplicationRunner {

    public void run(ApplicationArguments args) throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("simple-jpa-application");
        EntityManager em = emf.createEntityManager();

        EntityTransaction transaction = em.getTransaction();
        transaction.begin();

        Team team = new Team("team3", "팀3");
        em.persist(team);

        Member member1 = new Member("shjeon03", "회원03");
//        member1.setTeam(team);
        team.getMembers().add(member1);
        em.persist(team);

        Member member2 = new Member("shjeon04", "회원04");
//        member1.setTeam(team);
        team.getMembers().add(member2);
        em.persist(team);

        transaction.commit();
    }
}
