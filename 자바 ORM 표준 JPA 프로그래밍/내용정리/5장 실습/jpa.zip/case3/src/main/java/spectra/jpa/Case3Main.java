package spectra.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Case3Main {
    public static void main(String[] args) {
        SpringApplication.run(Case3Main.class, args);
    }
}
